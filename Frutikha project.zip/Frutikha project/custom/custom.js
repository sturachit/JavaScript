let data = localStorage.getItem("Category");
let category = JSON.parse(data);
//let data2 = {};

let row = '';   
for(let i = 0;i<category.length;i++){
   row += "<a href='index_1.html' class='nav-item nav-link'>"+category[i].cname+"</a>";
}  
document.getElementById("home").innerHTML = row;
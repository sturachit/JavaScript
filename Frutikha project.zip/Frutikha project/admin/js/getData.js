function getData() {
    let name = document.catform.name.value;
    category.push(name);
    localStorage.setItem("catName", name);
  }
  
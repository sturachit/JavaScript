let data = JSON.parse(localStorage.getItem("Category"));
let opt1 = "<option>----Select Cetegory-----</option>";
for (let i = 0; i < data.length; i++) {
     opt1 += "<option value=" + data[i].cid + ">" + data[i].cname + "</option>";
}
document.getElementById("catid").innerHTML = opt1;
// console.log('data',data)
disProduct();

document.getElementById("image").addEventListener("change", () => {
  let pimg = document.getElementById("image");
  if (pimg.files && pimg.files[0]) {
       let z = new FileReader();
       z.readAsDataURL(pimg.files[0]);
       z.addEventListener("load", () => {
            localStorage.setItem("ProductImage", z.result);
            document.proFrom.himage.value = z.result;
            document.proFrom.imgdisp.src = z.result;
       });
  }
});

display();
document.getElementById("btn1").addEventListener("click", function () {
  let cname = document.catform.catName.value;
  let cid = document.catform.cid.value;
  let pname = document.catform.pname.value;
  let img = document.catform.img.value;

  let data = JSON.parse(localStorage.getItem("Category"));
  let catdata ={};
  if(data != null){
    if(cid = ''){
      //update category
      for(let i = 0; i < data.category.length; i++){
        if(data.category[i].cid == cid){
          data.category[i].cname = cname;
          document.catform.cid.value= '';
          catdata =data;
        }
      }
    }else{
      //push
      let len = data.category.length;
      let obj ={
        cid :len +1,
        cname :cname
      };
      data.category.push(obj);
      catdata =data;
    }
  }else{
    let obj ={
      cid :1,
      cname :cname
    };
    catdata.category =[obj];
    
  }
  localStorage.setItem("Category",JSON.stringify(catdata));
  document.catform.reset();
  display();
});

function display() {
  let data = JSON.parse(localStorage.getItem("Category"));
  let row ='';
  if(data !=null){
    row +='<th class="px-5 text-success">Id</th>';
    row +='<th class="px-4 text-white">Category Name</th>';
    row +='<th class="px-4 text-white">Product Name</th>';
    row +='<th class="px-5 text-white">Image</th>';
    row +='<th class="px-5 text-warning ">Action</th>';
    row+='<tbody>';
    for(let i = 0; i <data.category.length; i++) {
      row += '<tr>';
      row += '<td class="px-5 text-success">' + data.category[i].cid + '</td>';
      row += '<td class="px-4 text-white">' + data.category[i].cname + '</td>';
      row += '<td class="px-4 text-white">' + data.category[i].pname + '</td>';
      row += '<td class="px-5 text-white">' + data.category[i].img + '</td>';
      row +='<td><button type="button" name="editData" class=" btn btn-primary ms-3 " id="editData" onClick="editCat('+data.category[i].cid+')">Edit </button>';
      row +='<button type="button" name="delData" class="ms-3 btn btn-danger " id="delData" onClick="delCat('+data.category[i].cid+')">Delete</button></td>';
      row +='</tr>';
    }
    row+='</tbody>';
  }
  document.getElementById("table").innerHTML = row;
}

function delCat(id){
  let data = JSON.parse(localStorage.getItem("Category"));
  id = id-1;
  let i=1;
  data.category.splice(id,1);
  for(let j=0;j<data.category.length;j++){
      data.category[j].cid = i;
      i++;
  }
  localStorage.setItem("Category", JSON.stringify(data));
  display();
}

function editCat(id){
  let data = JSON.parse(localStorage.getItem("Category"));
  if(data != null){
      for(let i=0;i<data.category.length;i++){
          if(data.category[i].cid == id){
            //   document.catform.catName.value = data.category[i].cname;
              document.catform.cid.value = data.category[i].cid;
              document.catform.pname.value = data.category[i].pname;
              document.catform.img.value = data.category[i].img;
          }
      }
  }
}


